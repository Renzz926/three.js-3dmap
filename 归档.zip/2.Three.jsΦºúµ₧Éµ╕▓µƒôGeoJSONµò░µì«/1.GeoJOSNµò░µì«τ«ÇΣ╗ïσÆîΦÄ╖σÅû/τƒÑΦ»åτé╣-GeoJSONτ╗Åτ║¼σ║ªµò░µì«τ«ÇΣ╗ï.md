# GeoJOSN数据简介

所谓GeoJSON数据，简单地说就是由经纬度等数据构成的一个json文件。

课程素材中提供了一些GeoJSON文件相关文件，比如world.json、worldZh.json、china.json、河南.json、郑州.json，你可打开预览。

`china.json`文件包含了中国各个省份边界轮廓的[经纬度](https://baike.baidu.com/item/%E7%BB%8F%E7%BA%AC%E5%BA%A6/1113442?fr=aladdin)坐标数据，`world.json`文件包含了世界各个国家边界轮廓的经纬度数据，`河南.json`文件包含了各个河南省各个市的边界数据。

### GeoJSON格式信息

如果你有一定的前端基础，那么你对JSON一定不陌生，**GeoJSON.json**文件就是通过JSON的键值对方式来表示地理相关信息，比如`coordinates`表示一个区域(国家、省份或城市)的边界经纬度坐标，`properties.name`属性表示一个行政区的名称...

一般你通过three.js解析渲染GeoJSON数据肯定首先要了解GeoJSON文件的数据结构，了解每个属性表示什么意思。

```JavaScript
// china.json文件结构简单注意
{
    "type": "FeatureCollection",
    "features": [
        {
            "type": "Feature",
            "properties": {
              "id": "41",
              "name": "河南",
              "cp": [113.4668, 33.8818],
              "childNum": 17
            },
            "geometry": {
                //表示河南省由一个多边形轮廓构成
              "type": "Polygon",
              "coordinates": [
                [
                  [110.3906, 34.585],
                  [110.8301, 34.6289]
                //   ...等经纬度坐标数据
                ]
              ]
            }
        },    {
            "type": "Feature",
            "properties": {
              "id": "13",
              "name": "河北",
              "cp": [115.4004, 37.9688],
              "childNum": 11
            },
            "geometry": {
            // MultiPolygon：表示河北省包含多个封闭多边形轮廓
            //类似还有，很多过的领土不一定是连续会被海洋隔开或者在其它国家存在飞地
              "type": "MultiPolygon",
              "coordinates": [
                [
                    //河北省多边形轮廓1
                  [
                    [114.5215, 39.5068],
                    [114.3457, 39.8584]
                    //   ...等经纬度坐标数据
                  ]
                ],
                [
                    // 河北省多边形轮廓2：北京和天津之间的一块飞地
                  [
                    [117.2461, 40.0781],
                    //   ...等经纬度坐标数据
                  ]
                ]
              ]
            }
          }
    ]
  }  
```

### `全国不同城市PM2.5.json`结构

`全国不同城市PM2.5.json`不能算符合GeoJSON标准的文件，可以理解一个包含经纬度数据和PM2.5信息的自定义JSON文件即可，就像你平时开发前端Web项目是遇到的json文件，直接解析对应的属性即可。


