### three.js官方文件目录资源介绍

```JavaScript
three.js-master
└───build——src目录下各个代码模块打包后的结果
    │───three.js——开发的时候.html文件中要引入的threejs引擎库，和引入jquery一样，可以辅助浏览器调试
    │───three.min.js——three.js压缩后的结构文件体积更小，可以部署项目的时候在.html中引入。
    │───three.module.js——支持import语法在.html文件中引入thre。
└───docs——Three.js API文档文件
    │───index.html——打开该文件可以实现离线查看threejs API文档
    │
└───editor——Three.js的可视化编辑器，可以编辑3D场景
    │───index.html——打开应用程序
    │
└───docs——Three.js API文档文件
    │───index.html——打开该文件可以实现离线查看threejs API文档
    │
└───examples——里面有大量的threejs案例，可以参考学习
    │──/js/——three.js扩展库
    │──/jsm/——和js目录下一样是three.js扩展库，可以import引入    
    │
└───src——Three.js引擎的各个模块，可以通过阅读源码深度理解threejs引擎
    │───index.html——打开该文件可以实现离线查看threejs API文档
    │
└───utils——一些辅助工具
    │───\utils\exporters\blender——blender导出threejs文件的插件
```



### .html引入three.js文件

如果你想在.html文件中使用three.js库，可以直接通过script标签在.html文件引入three.js文件即可。
```html
  <!--引入three.js三维引擎-->
  <script src="./three.js-r123/build/three.js"></script>
```

three.js除了本身核心代码意外，还有大量的用于实现特定功能的扩展库，比如控制相机旋转缩放的相机控件`OrbitControls.js`
```html
    <!-- 引入threejs扩展控件OrbitControls.js -->
    <script src="./three.js-r123/examples/js/controls/OrbitControls.js"></script>
```

### .html文件中import方式引入Three.js

原来浏览器并不支持在.html文件中通过import引入js文件，往往需要通过nodejs配置好开发环境才能使用关键词`export`和`import`进行模块化开发，现在浏览器普遍支持`export`和`import`。

```html
<script type="module">
// 现在浏览器支持ES6语法，自然包括import方式引入js文件
import * as THREE from './three.js-r123/build/three.module.js';
// 引入Three.js扩展库
import { OrbitControls } from './three.js-r123/examples/jsm/controls/OrbitControls.js';
</script>
```

### npm安装

一般学习教程或者编写一个demo，为了方便可以直接在.html文件中引入thre.js相关文件，不过在正式开发的时候，你可以在你的nodejs工程文件中，通过npm命令行安装three.js。

```JavaScript
npm install three --save
```
模块化开发import引入。

```JavaScript
// 引入three.js，获得threejs库全部API
import * as THREE from 'three';
// 和在.html文件中一样使用threejs类
...
var geo = new THREE.PlaneGeometry(105,209)
...
var renderer = new THREE.WebGLRenderer({
  antialias: true
});
```

```JavaScript
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
const controls = new OrbitControls(camera, renderer.domElement);
```